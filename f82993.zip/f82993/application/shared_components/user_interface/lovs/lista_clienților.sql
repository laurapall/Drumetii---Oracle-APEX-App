prompt --application/shared_components/user_interface/lovs/lista_clienților
begin
--   Manifest
--     LISTA CLIENȚILOR
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.1'
,p_default_workspace_id=>56919689394143710057
,p_default_application_id=>82993
,p_default_id_offset=>0
,p_default_owner=>'WKSP_LAURAPALL'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(54274002051429314499)
,p_lov_name=>unistr('LISTA CLIEN\021AILOR')
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_query_table=>'D_CLIENTI'
,p_return_column_name=>'COD_CLIENT'
,p_display_column_name=>'NUME'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
);
wwv_flow_imp.component_end;
end;
/

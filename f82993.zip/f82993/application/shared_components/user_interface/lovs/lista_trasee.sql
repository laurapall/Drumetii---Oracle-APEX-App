prompt --application/shared_components/user_interface/lovs/lista_trasee
begin
--   Manifest
--     LISTA TRASEE 
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.1'
,p_default_workspace_id=>56919689394143710057
,p_default_application_id=>82993
,p_default_id_offset=>0
,p_default_owner=>'WKSP_LAURAPALL'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(54219687524509845029)
,p_lov_name=>'LISTA TRASEE '
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select D_TRASEE.COD_TRASEE as COD_TRASEE,',
'    D_TRASEE.DENUMIRE as DENUMIRE,',
'    D_TRASEE.DATA as DATA,',
'    D_TRASEE.PRET as PRET,',
'    (prenume || '' '' || nume) as nume,',
'    D_GHIZI.TELEFON as TELEFON,',
'    D_GHIZI."E-MAIL" as "E-MAIL" ',
' from D_GHIZI D_GHIZI,',
'    D_TRASEE D_TRASEE ',
' where D_TRASEE.COD_GHID=D_GHIZI.COD_GHID'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'COD_TRASEE'
,p_display_column_name=>'DENUMIRE'
,p_default_sort_column_name=>'DENUMIRE'
,p_default_sort_direction=>'ASC'
);
wwv_flow_imp.component_end;
end;
/

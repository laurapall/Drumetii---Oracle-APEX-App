prompt --application/shared_components/user_interface/lovs/lista_trasee2
begin
--   Manifest
--     LISTA TRASEE2
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.1'
,p_default_workspace_id=>56919689394143710057
,p_default_application_id=>82993
,p_default_id_offset=>0
,p_default_owner=>'WKSP_LAURAPALL'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(54228379779470501247)
,p_lov_name=>'LISTA TRASEE2'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'D_TRASEE'
,p_return_column_name=>'COD_TRASEE'
,p_display_column_name=>'DENUMIRE'
,p_default_sort_column_name=>'DENUMIRE'
,p_default_sort_direction=>'ASC'
);
wwv_flow_imp.component_end;
end;
/

prompt --application/shared_components/user_interface/lovs/lista_ghizi
begin
--   Manifest
--     LISTA GHIZI
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.1'
,p_default_workspace_id=>56919689394143710057
,p_default_application_id=>82993
,p_default_id_offset=>0
,p_default_owner=>'WKSP_LAURAPALL'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(54172409633267008638)
,p_lov_name=>'LISTA GHIZI'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select D_GHIZI.COD_GHID as COD_GHID,',
'(prenume || '' '' || nume) as nume, ',
'     D_GHIZI.TELEFON as TELEFON,',
'    D_GHIZI."E-MAIL" as "E-MAIL" ',
' from D_GHIZI D_GHIZI',
' order by nume asc'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'COD_GHID'
,p_display_column_name=>'NUME'
);
wwv_flow_imp.component_end;
end;
/

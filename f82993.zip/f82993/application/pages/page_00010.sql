prompt --application/pages/page_00010
begin
--   Manifest
--     PAGE: 00010
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.1'
,p_default_workspace_id=>56919689394143710057
,p_default_application_id=>82993
,p_default_id_offset=>0
,p_default_owner=>'WKSP_LAURAPALL'
);
wwv_flow_imp_page.create_page(
 p_id=>10
,p_name=>unistr('Ad\0103ugare comand\0103')
,p_alias=>unistr('AD\0102UGARE-COMAND\0102')
,p_step_title=>unistr('Ad\0103ugare comand\0103')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_last_updated_by=>'PALLLAURA80@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230219141702'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(54141535157957884148)
,p_name=>'Lista comenzi'
,p_template=>wwv_flow_imp.id(54116685935508371652)
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select D_COMANDA.COD_CLIENT as COD_CLIENT,',
'    D_COMANDA.COD_TRASEE as COD_TRASEE,',
'    D_CLIENTI.NUME as NUME,',
'    D_CLIENTI.PRENUME as PRENUME,',
'    D_CLIENTI.COD_LOCALITATE as COD_LOCALITATE,',
'    D_LOCALITATE.LOCALITATE as LOCALITATE,',
'    D_CLIENTI.ADRESA as ADRESA,',
'    D_CLIENTI.TELEFON as TELEFON,',
'    D_CLIENTI.EMAIL as EMAIL,',
'    D_TRASEE.DENUMIRE as DENUMIRE,',
'    D_TRASEE.PRET as PRET,',
'    D_COMANDA.DATA_TRASEE as DATA_TRASEE ',
' from D_CLIENTI D_CLIENTI,',
'    D_COMANDA D_COMANDA,',
'    D_TRASEE D_TRASEE, ',
'    D_LOCALITATE D_LOCALITATE',
' where D_TRASEE.COD_TRASEE=D_COMANDA.COD_TRASEE',
'    and D_COMANDA.COD_CLIENT=D_CLIENTI.COD_CLIENT',
'    AND D_CLIENTI.COD_LOCALITATE=D_LOCALITATE.COD_LOCALITATE'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(54116723822607371667)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(54141535230447884149)
,p_query_column_id=>1
,p_column_alias=>'COD_CLIENT'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(54141535311911884150)
,p_query_column_id=>2
,p_column_alias=>'COD_TRASEE'
,p_column_display_sequence=>20
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(54402545562434552401)
,p_query_column_id=>3
,p_column_alias=>'NUME'
,p_column_display_sequence=>30
,p_column_heading=>'Nume'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(54402545690464552402)
,p_query_column_id=>4
,p_column_alias=>'PRENUME'
,p_column_display_sequence=>40
,p_column_heading=>'Prenume'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(54402545768898552403)
,p_query_column_id=>5
,p_column_alias=>'COD_LOCALITATE'
,p_column_display_sequence=>50
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(54402546435925552410)
,p_query_column_id=>6
,p_column_alias=>'LOCALITATE'
,p_column_display_sequence=>60
,p_column_heading=>'Localitate'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(54402545851710552404)
,p_query_column_id=>7
,p_column_alias=>'ADRESA'
,p_column_display_sequence=>70
,p_column_heading=>'Adresa'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(54402545933466552405)
,p_query_column_id=>8
,p_column_alias=>'TELEFON'
,p_column_display_sequence=>80
,p_column_heading=>'Telefon'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(54402546031383552406)
,p_query_column_id=>9
,p_column_alias=>'EMAIL'
,p_column_display_sequence=>90
,p_column_heading=>'Email'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(54402546160821552407)
,p_query_column_id=>10
,p_column_alias=>'DENUMIRE'
,p_column_display_sequence=>100
,p_column_heading=>'Denumire trasee'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(54402546250610552408)
,p_query_column_id=>11
,p_column_alias=>'PRET'
,p_column_display_sequence=>110
,p_column_heading=>unistr('Pre\021B')
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(54402546313504552409)
,p_query_column_id=>12
,p_column_alias=>'DATA_TRASEE'
,p_column_display_sequence=>120
,p_column_heading=>'Data'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(54389001988305042379)
,p_plug_name=>unistr('Ad\0103ugare comand\0103')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(54116685935508371652)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(54389002493829042380)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(54389001988305042379)
,p_button_name=>'SUBMIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(54116758885146371683)
,p_button_image_alt=>'Submit'
,p_button_position=>'CHANGE'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(54389002322699042380)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(54389001988305042379)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(54116758885146371683)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:2:&APP_SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(54389006817625042391)
,p_branch_name=>'Go To Page 2'
,p_branch_action=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(54389002493829042380)
,p_branch_sequence=>1
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(54141535021106884147)
,p_name=>'P10_JUD'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(54389001988305042379)
,p_prompt=>unistr('Jude\021B')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>unistr('LISTA JUDE\021AELOR')
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(54116756323186371682)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(54389003215331042388)
,p_name=>'P10_ME1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(54389001988305042379)
,p_prompt=>'Nume'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(54116756323186371682)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(54389003654168042389)
,p_name=>'P10_ENUME1'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(54389001988305042379)
,p_prompt=>'Prenume'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(54116756323186371682)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(54389004074961042389)
,p_name=>'P10_DLOC'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(54389001988305042379)
,p_prompt=>'Localitate'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select D_LOCALITATE.LOCALITATE as LOCALITATE,',
'    D_LOCALITATE.COD_LOCALITATE as COD_LOCALITATE ',
' from D_LOCALITATE D_LOCALITATE',
' where COD_JUDET=:P10_JUD'))
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P10_JUD'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(54116756323186371682)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(54389004482736042389)
,p_name=>'P10_RESA1'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(54389001988305042379)
,p_prompt=>'Adresa'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(54116756323186371682)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(54389004887879042390)
,p_name=>'P10_LEFON1'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(54389001988305042379)
,p_prompt=>'Telefon'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(54116756323186371682)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(54389005222907042390)
,p_name=>'P10_AIL1'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(54389001988305042379)
,p_prompt=>'Email'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(54116756323186371682)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(54389005638162042390)
,p_name=>'P10_TA1'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(54389001988305042379)
,p_prompt=>'Data trasee'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(54116756323186371682)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(54389006000137042390)
,p_name=>'P10_DTRASEE'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(54389001988305042379)
,p_prompt=>'Nume trasee'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LISTA TRASEE2'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(54116756323186371682)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(54389006406953042391)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Run Stored Procedure'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'"#OWNER#"."P_COMENZI"(',
'"NUME1" => :P10_ME1,',
'"PRENUME1" => :P10_ENUME1,',
'"CODLOC" => :P10_DLOC,',
'"ADRESA1" => :P10_RESA1,',
'"TELEFON1" => :P10_LEFON1,',
'"EMAIL1" => :P10_AIL1,',
'"DATA1" => :P10_TA1,',
'"CODTRASEE" => :P10_DTRASEE);'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>unistr('Eroare \00EEnregistrare.')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(54389002493829042380)
,p_process_success_message=>unistr('\00CEnregistrare comand\0103 cu succes.')
,p_internal_uid=>54389006406953042391
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(54141534915279884146)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'Golire'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>54141534915279884146
);
wwv_flow_imp.component_end;
end;
/

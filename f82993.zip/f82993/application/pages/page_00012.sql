prompt --application/pages/page_00012
begin
--   Manifest
--     PAGE: 00012
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.1'
,p_default_workspace_id=>56919689394143710057
,p_default_application_id=>82993
,p_default_id_offset=>0
,p_default_owner=>'WKSP_LAURAPALL'
);
wwv_flow_imp_page.create_page(
 p_id=>12
,p_name=>'Gestionarea comenzilor2'
,p_alias=>'GESTIONAREA-COMENZILOR2'
,p_step_title=>'Gestionarea comenzilor2'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_last_updated_by=>'PALLLAURA80@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230219183053'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(54402546533611552411)
,p_plug_name=>'Alege client'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(54116685935508371652)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(54402546853697552414)
,p_name=>'Comenzi'
,p_parent_plug_id=>wwv_flow_imp.id(54402546533611552411)
,p_template=>wwv_flow_imp.id(54116685935508371652)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select D_CLIENTI.COD_CLIENT as COD_CLIENT,',
'    D_TRASEE.COD_TRASEE as COD_TRASEE,',
'    D_TRASEE.DENUMIRE as DENUMIRE,',
'    D_TRASEE.PRET as PRET,',
'    D_COMANDA.DATA_TRASEE as DATA_TRASEE ',
' from D_TRASEE D_TRASEE,',
'    D_COMANDA D_COMANDA,',
'    D_CLIENTI D_CLIENTI ',
' where D_COMANDA.COD_TRASEE=D_TRASEE.COD_TRASEE',
'    and D_COMANDA.COD_CLIENT=D_CLIENTI.COD_CLIENT',
'    and D_CLIENTI.COD_CLIENT=:P12_CLIENT',
'    '))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(54116723822607371667)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(54402546943307552415)
,p_query_column_id=>1
,p_column_alias=>'COD_CLIENT'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(54402547089884552416)
,p_query_column_id=>2
,p_column_alias=>'COD_TRASEE'
,p_column_display_sequence=>20
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(54402547111763552417)
,p_query_column_id=>3
,p_column_alias=>'DENUMIRE'
,p_column_display_sequence=>30
,p_column_heading=>'Denumire'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(54402547252090552418)
,p_query_column_id=>4
,p_column_alias=>'PRET'
,p_column_display_sequence=>40
,p_column_heading=>'Pret'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(54402547347439552419)
,p_query_column_id=>5
,p_column_alias=>'DATA_TRASEE'
,p_column_display_sequence=>50
,p_column_heading=>'Data Trasee'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(54402549924513552445)
,p_plug_name=>'Alege trasee'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(54116685935508371652)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(54402550287050552448)
,p_name=>unistr('Clien\021Bi')
,p_parent_plug_id=>wwv_flow_imp.id(54402549924513552445)
,p_template=>wwv_flow_imp.id(54116685935508371652)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select D_TRASEE.COD_TRASEE as COD_TRASEE,',
'    D_CLIENTI.COD_CLIENT as COD_CLIENT,',
'    D_CLIENTI.NUME as NUME,',
'    D_CLIENTI.PRENUME as PRENUME,',
'    D_CLIENTI.ADRESA as ADRESA,',
'    D_CLIENTI.TELEFON as TELEFON,',
'    D_CLIENTI.EMAIL as EMAIL ',
' from D_CLIENTI D_CLIENTI,',
'    D_TRASEE D_TRASEE,',
'    D_COMANDA D_COMANDA ',
' where D_TRASEE.COD_TRASEE=D_COMANDA.COD_TRASEE',
'    and D_CLIENTI.COD_CLIENT=D_COMANDA.COD_CLIENT',
'    and D_trasee.cod_trasee=:P12_TRASEE'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(54116723822607371667)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(54417518602575658506)
,p_query_column_id=>1
,p_column_alias=>'COD_TRASEE'
,p_column_display_sequence=>70
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(54402550351787552449)
,p_query_column_id=>2
,p_column_alias=>'COD_CLIENT'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(54402550403843552450)
,p_query_column_id=>3
,p_column_alias=>'NUME'
,p_column_display_sequence=>20
,p_column_heading=>'Nume'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(54417519362931658513)
,p_query_column_id=>4
,p_column_alias=>'PRENUME'
,p_column_display_sequence=>30
,p_column_heading=>'Prenume'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(54417518326688658503)
,p_query_column_id=>5
,p_column_alias=>'ADRESA'
,p_column_display_sequence=>40
,p_column_heading=>'Adresa'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(54417518427203658504)
,p_query_column_id=>6
,p_column_alias=>'TELEFON'
,p_column_display_sequence=>50
,p_column_heading=>'Telefon'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(54417518529197658505)
,p_query_column_id=>7
,p_column_alias=>'EMAIL'
,p_column_display_sequence=>60
,p_column_heading=>'Email'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(54402546635214552412)
,p_name=>'P12_CLIENT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(54402546533611552411)
,p_prompt=>'Nume client'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>unistr('LISTA CLIEN\021AILOR')
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(54116756323186371682)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(54402550015822552446)
,p_name=>'P12_TRASEE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(54402549924513552445)
,p_prompt=>'Trasee'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LISTA TRASEE2'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(54116756323186371682)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'N'
);
wwv_flow_imp.component_end;
end;
/

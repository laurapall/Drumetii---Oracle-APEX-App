prompt --application/pages/page_00006
begin
--   Manifest
--     PAGE: 00006
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.1'
,p_default_workspace_id=>56919689394143710057
,p_default_application_id=>82993
,p_default_id_offset=>0
,p_default_owner=>'WKSP_LAURAPALL'
);
wwv_flow_imp_page.create_page(
 p_id=>6
,p_name=>unistr('Ad\0103ugare localitate')
,p_alias=>unistr('AD\0102UGARE-LOCALITATE')
,p_step_title=>unistr('Ad\0103ugare localitate')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'02'
,p_last_updated_by=>'PALLLAURA80@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230218100358'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(47329295509059656249)
,p_name=>unistr('Lista localit\0103\021Bilor')
,p_template=>wwv_flow_imp.id(54116685935508371652)
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select D_LOCALITATE.COD_LOCALITATE as COD_LOCALITATE,',
'    D_LOCALITATE.LOCALITATE as LOCALITATE,',
'    D_LOCALITATE.COD_JUDET as COD_JUDET,',
'    D_JUDET.JUDET as JUDET ',
' from D_JUDET D_JUDET,',
'    D_LOCALITATE D_LOCALITATE ',
' where D_LOCALITATE.COD_JUDET=D_JUDET.COD_JUDET',
' order by D_LOCALITATE.LOCALITATE ASC'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(54116723822607371667)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47329295600481656250)
,p_query_column_id=>1
,p_column_alias=>'COD_LOCALITATE'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(54141530569906884102)
,p_query_column_id=>2
,p_column_alias=>'LOCALITATE'
,p_column_display_sequence=>30
,p_column_heading=>'Localitate'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(54141530436330884101)
,p_query_column_id=>3
,p_column_alias=>'COD_JUDET'
,p_column_display_sequence=>20
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(54141530696258884103)
,p_query_column_id=>4
,p_column_alias=>'JUDET'
,p_column_display_sequence=>40
,p_column_heading=>unistr('Jude\021B')
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(54141445951827864378)
,p_plug_name=>unistr('Ad\0103ugare localitate')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(54116685935508371652)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'D_LOCALITATE'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(54141448316381864380)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(54141445951827864378)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(54116758885146371683)
,p_button_image_alt=>'Abandon'
,p_button_position=>'CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:6:&APP_SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(54141449774039864381)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(54141445951827864378)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(54116758885146371683)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Ad\0103ugare localitate')
,p_button_position=>'CREATE'
,p_button_condition=>'P6_COD_LOCALITATE'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(54141450049324864381)
,p_branch_action=>'f?p=&APP_ID.:6:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(54141446262569864378)
,p_name=>'P6_COD_LOCALITATE'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(54141445951827864378)
,p_item_source_plug_id=>wwv_flow_imp.id(54141445951827864378)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Cod Localitate'
,p_source=>'COD_LOCALITATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(54116756323186371682)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(54141446675414864379)
,p_name=>'P6_COD_JUDET'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(54141445951827864378)
,p_item_source_plug_id=>wwv_flow_imp.id(54141445951827864378)
,p_prompt=>unistr('Alege jude\021B')
,p_source=>'COD_JUDET'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>unistr('LISTA JUDE\021AELOR')
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(54116756323186371682)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(54141447064741864379)
,p_name=>'P6_LOCALITATE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(54141445951827864378)
,p_item_source_plug_id=>wwv_flow_imp.id(54141445951827864378)
,p_prompt=>'Localitate'
,p_source=>'LOCALITATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>50
,p_field_template=>wwv_flow_imp.id(54116756323186371682)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(54141450980446864382)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(54141445951827864378)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>unistr('Process form Ad\0103ugare localitate')
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_process_error_message=>unistr('Eroare ad\0103ugare date.')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>unistr('Ad\0103ugarea localit\0103\021Bii s-a reu\0219it cu succes.')
,p_internal_uid=>54141450980446864382
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(54141450500594864382)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(54141445951827864378)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>unistr('Initialize form Ad\0103ugare localitate')
,p_internal_uid=>54141450500594864382
);
wwv_flow_imp.component_end;
end;
/

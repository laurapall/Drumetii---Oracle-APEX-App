prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.1'
,p_default_workspace_id=>56919689394143710057
,p_default_application_id=>82993
,p_default_id_offset=>0
,p_default_owner=>'WKSP_LAURAPALL'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>unistr('Ad\0103ugarea datelor')
,p_alias=>unistr('AD\0102UGAREA-DATELOR')
,p_step_title=>unistr('Ad\0103ugarea datelor')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'11'
,p_last_updated_by=>'PALLLAURA80@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230218080610'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(47329294702046656241)
,p_plug_name=>unistr('Ad\0103ugarea datelor \00EEn baza de date')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(54116685935508371652)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<h3>Pute\021Bi ad\0103uga date despre: </h3>'),
'<ul>',
unistr('<li> Clien\021Bi </li>'),
'<li> Ghizi </li>',
'<li>Trasee </li>',
'<li>Comenzi</li>',
'</ul>',
'</p>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp.component_end;
end;
/
